#include "mbed.h"
#include "rtos.h"
#include "TextLCD.h"

TextLCD lcd(p15, p16, p17, p18, p19, p20, TextLCD::LCD20x4);
RawSerial pc(USBTX, USBRX); // tx, rx
DigitalOut aget(p26);
DigitalOut vget(p27);
DigitalOut reset(p21);
InterruptIn apace(p7);
InterruptIn vpace(p8);

void mode_thread(void const *);
void display_thread(void const *);
void led_thread(void const *);

Thread modeThread(mode_thread);
Thread displayThread(display_thread);
Thread ledThread4(led_thread);

int minWaitA;
int minWaitV;
const uint32_t MINWAIT_A_MS = 10;
const uint32_t MINWAIT_V_MS = 15;
const uint32_t MAXWAIT_HEART_MS = 2000;

Timer dispClk, master, testTimer;
long lastDispUpdate=0;
long timestamp;

// FLAGS
int fAget_led = 0;
int fVget_led = 0;
int fApace_led = 0;
int fVpace_led = 0;
int fHeartKeyA_mode = 0;
int fHeartKeyV_mode = 0;
int interval = 10;
int beats = 0;

int fAP_test = 0;
int fVP_test = 0;

int md = 0;
int HeartRateLower[4] = {40,30,100,30};
int HeartRateUpper[4] = {100,60,175,175};

int TLRI[4]={1500, 2000, 600, 2000};
int TURI[4]={600, 1000, 343, 343};
 
int TAVI_l=30;
int TVRP_l=150;
int TPVARP_l=100;

int TAVI_u=100;
int TVRP_u=500;
int TPVARP_u=500;

enum Signal 
{
    VGET,AGET,HEART_TEST,HEART_RANDOM,HEART_MANUAL
};
enum State 
{
    TESTMODE, RANDOMMODE, MANUALMODE
};

class heart1 
{
    private:
        State myState;

    public:
        void init() 
        { 
            reset = 0;
            tran(RANDOMMODE); 
        }
        void dispatch(unsigned const sig) 
        {
            switch(sig)
            {
                case HEART_TEST: 
                    tran(TESTMODE); 
                    reset = 1;
                    wait_us(20);
                    reset = 0;
                    lastDispUpdate=dispClk.read(); 
                    beats = 0;
                    pc.printf("Heart in TEST MODE!\n\r");
                    break;
                case HEART_MANUAL: 
                    tran(MANUALMODE); 
                    reset = 1;
                    wait_us(20);
                    reset = 0;
                    lastDispUpdate=dispClk.read(); 
                    beats = 0;
                    pc.printf("Heart in MANUAL MODE!\n\r");
                    break;
                case HEART_RANDOM: 
                    tran(RANDOMMODE); 
                    reset = 1;
                    wait_us(20);
                    reset = 0;
                    lastDispUpdate=dispClk.read(); 
                    beats = 0;
                    pc.printf("Heart in RANDOM MODE!\n\r");
                    break;
            }
        }
        void tran(State target) 
        { 
            myState = target; 
        }
        State getState()
        {
            return myState;
        }
};

heart1 heart;

void send_aget()
{
    aget = 1;
    fAget_led = 1;
    wait_us(20);
    aget = 0;
}

void send_vget()
{
    vget = 1;
    fVget_led = 1;
    wait_us(20);
    vget = 0;
}

void reset_pacemaker()
{
    reset = 1;
    wait_us(20);
    reset = 0;
}

void Test1()
{
    pc.printf("\n\rTest1 : LRI\r\n");
    reset_pacemaker();
    
    fAP_test = 0;
    fVP_test = 0;
    
    unsigned int waitTime = TLRI[md];
    
    long tim;
    
    while(fVP_test != 1)
    {   
        tim = testTimer.read_ms();
    }
    testTimer.reset();
    fVP_test = 0;
    while(fAP_test != 1)
    {   
        tim = testTimer.read_ms();
        if(tim > waitTime)
        {
            pc.printf("LRI Timeout 2\n\r");
            break;       
        }
    }
    fAP_test = 0;
    while(fVP_test != 1)
    {   
        tim = testTimer.read_ms();
        if(tim > waitTime+2000)
        {
            pc.printf("LRI Timeout 3\n\r");
            break;       
        }
    }
    
    if(tim <= waitTime)
    {
        pc.printf("LRI Test : Limit: %d, Actual Time: %d\n\r", waitTime,tim);
        pc.printf("LRI test passed. (The interval between two ventricular events is lower than LRI)\r\n");
    }
    else
    {
        pc.printf("LRI test Failed, waited for %d\r\n", tim);
    }
}

void Test2()
{
    pc.printf("\n\rTest2 : URI\r\n");
    reset_pacemaker();

    fAP_test = 0;
    fVP_test = 0;

    long tim = testTimer.read_ms();
    
    while(fVP_test != 1)
    {   
        tim = testTimer.read_ms();
    }

    testTimer.reset();
    fVP_test = 0;
    
    wait_ms(TPVARP_l+100);
    
    send_aget();
    
    while(fVP_test != 1)
    {   
        tim = testTimer.read_ms();
        if(tim > TLRI[md])
        {
            pc.printf("URI Timeout \n\r");
            break;       
        }
    }
    tim = testTimer.read_ms();
    
    fVP_test = 0;
    long limitTime = TURI[md];   
 
    if(tim >= limitTime)
    {
        pc.printf("URI Test : Limit: %d, Actual Time: %d\n\r", limitTime,tim);
        pc.printf("URI test passed. (The interval between two ventricular events is more than URI)\r\n");
    }
    else
    {
        pc.printf("URI test Failed, arrived before %d\r\n", tim);
    }
}

void Test3()
{
    pc.printf("\n\rTest3 : VRP\r\n");
    reset_pacemaker();

    long tim = testTimer.read_ms();
   
    fAP_test = 0;
    fVP_test = 0;
    
    send_vget();
    timestamp = master.read_ms();
    pc.printf("%ld:%ld:%ld      Sent VSignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    int waitTime = TVRP_l/2;
    send_vget();
    timestamp = master.read_ms();
    pc.printf("%ld:%ld:%ld      Sent VSignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    pc.printf("Test Completed\r\n");
}

void Test4()
{
    
    reset_pacemaker();

    fAP_test = 0;
    fVP_test = 0;
    
    long tim = testTimer.read_ms();
    while(fAP_test != 1)
    {   
        tim = testTimer.read_ms();
    }
    
    fVP_test = 0;
    testTimer.reset();

    tim = testTimer.read_ms();
    tim = testTimer.read_ms();
    
    unsigned int waitTime = TAVI_l;
    
    while(fVP_test != 1)
    {   
        tim = testTimer.read_ms();
        if(tim > TAVI_u)
        {
//            pc.printf("AVI Timeout\n\r");
            break;
        }
    }
    wait_ms(10);
    tim = testTimer.read_ms();

    if(tim >= waitTime)
    {
        pc.printf("\n\rTest4 : AVI\r\n");
        pc.printf("AVI Test : LowerLimit: %d, Actual Time: %d\n\r", waitTime,tim);
        pc.printf("AVI test passed. (The interval between atrial and next ventricular event should be greater than the limit)\r\n");
    }
    else
    {
//        pc.printf("AVI test Failed, waited for %d.\r\n", tim);
    }
}



void Test5()
{
    pc.printf("\n\rTest5 : PVARP\r\n");
    reset_pacemaker();

    fAP_test = 0;
    fVP_test = 0;
        
    send_vget();
    timestamp = master.read_ms();
    pc.printf("%ld:%ld:%ld      Sent VSignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    long waitTime = TPVARP_l/2;
    wait_ms(waitTime);
    send_aget();
    timestamp = master.read_ms();
    pc.printf("%ld:%ld:%ld      Sent ASignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    waitTime = (TPVARP_l+TPVARP_u/2)-TPVARP_l/2;
    wait_ms(waitTime);
    send_aget();
    timestamp = master.read_ms();
    pc.printf("%ld:%ld:%ld      Sent ASignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    pc.printf("Test Completed\r\n");   
}

void mode_thread(void const *args) 
{
    heart.init();
    while(1)
    {
        switch(heart.getState())
        {
            case RANDOMMODE:
                int signalSelect = rand()%2;
                if(signalSelect==1)
                {
                    minWaitA = (rand() % ((MAXWAIT_HEART_MS - MINWAIT_A_MS) + 1)) + MINWAIT_A_MS;
                    wait_ms(minWaitA);
                    aget = 1;
                    fAget_led = 1;
                    wait_us(20);
                    aget = 0;
                }
                else
                {
                    minWaitV = rand() % ((MAXWAIT_HEART_MS - MINWAIT_V_MS) + 1) + MINWAIT_V_MS;
                    wait_ms(minWaitV);
                    vget = 1;
                    fVget_led = 1;
                    wait_us(20);
                    vget = 0;
                    beats++;
                }
            break;
    
            case MANUALMODE:
                if(fHeartKeyA_mode) 
                {
                    //pc.printf("Aget");
                    aget = 1;
                    fAget_led = 1;
                    wait_us(20);
                    aget = 0;
                    wait_ms(20);
                    aget = 1;
                    wait_us(20);
                    aget = 0;
                    fHeartKeyA_mode = 0;
                    timestamp = master.read_ms();
                    pc.printf("%ld:%ld:%ld      Manual ASignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
                }
                if(fHeartKeyV_mode)
                {
                    //pc.printf("Vget");
                    vget = 1;
                    fVget_led = 1;
                    wait_us(20);
                    vget = 0;
                    fHeartKeyV_mode = 0;
                    beats++;
                    timestamp = master.read_ms();
                    pc.printf("%ld:%ld:%ld      Manual VSignal!      \n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
                }
            break;    
            
            case(TESTMODE):
                int testSelect = rand()%5 + 1;
                switch(testSelect)
                {
                    case 1:
                        Test1();    
                    break;
                    case 2:
                        Test2();
                    break;
                    case 3:
                        Test3();
                    break;
                    case 4:
                        Test4();
                    break;
                    case 5:
                        Test5();
                    break;
                }
                wait(1);       
            break;
        }
    }
}

void led_thread(void const *args) 
{
    DigitalOut led1(LED1);  //Aget
    DigitalOut led2(LED2);  //Apace
    DigitalOut led3(LED3);  //Vget
    DigitalOut led4(LED4);  //Vpace
    
    while(1)
    {
        if(fAget_led) {
            fAget_led = 0;
            led1 = 1;
        }
        if(fVget_led) {
            fVget_led = 0;
            led3 = 1;
        }
        if(fApace_led) {
            fApace_led = 0;
            led2 = 1;
        }
        if(fVpace_led) {
            fVpace_led = 0;
            led4 = 1;
        }
        if(led1 == 1 || led2 == 1 || led3 == 1 || led4 == 1)
            wait_ms(50);               
        led1 = 0;led2 = 0; led3 = 0; led4 = 0;
    }
}

void display_thread(void const *args)
{
    dispClk.start();
    while(1)
    {
        //pc.printf("%f\n\r",(float)dispClk.read()-lastDispUpdate);
        if((dispClk.read()-lastDispUpdate) > interval)
        {
            int rate = (int)(60*(float)beats/(float)interval);
            lcd.locate(0,0);
            lcd.printf("bpm:    %3d   ",rate);
            beats = 0;
            lastDispUpdate = dispClk.read();
            if(heart.getState()!=TESTMODE)
                pc.printf("\n\rDisplay Updated: %d bpm \n\r", rate);
        }
        wait(1);
    }    
}



void Rx_interrupt () 
{
    if(pc.readable())
    {
        char t = pc.getc();
        char command[3];
        switch(t)
        {
            case 'R': heart.dispatch(HEART_RANDOM); break;
            case 'M': heart.dispatch(HEART_MANUAL); break;
            case 'T': heart.dispatch(HEART_TEST); break;
            case 'A': fHeartKeyA_mode = 1; break;
            case 'V': fHeartKeyV_mode = 1; break;
            case 'O': 
                int i = 0;
                pc.printf("\n\r Set Observation Interval : ");
                while(t!='\r')
                {
                    t = pc.getc();
                    command[i++] = t;    
                }
                interval = atoi(command);
                lastDispUpdate=dispClk.read(); 
                beats = 0;
                timestamp = master.read_ms();
                pc.printf("%d \n\r",interval);
                break;
        }
    }
}

void apace_isr() 
{
    fApace_led = 1;
    fAget_led = 1;
    timestamp = master.read_ms();
    if(heart.getState()!=TESTMODE)
        pc.printf("%ld:%ld:%ld      APace!\n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    
    fAP_test = 1;;
}

void vpace_isr() {
    fVpace_led = 1;
    fVget_led = 1;
    timestamp = master.read_ms();
    if(heart.getState()!=TESTMODE)
        pc.printf("%ld:%ld:%ld      VPace!\n\r",timestamp/60000, (timestamp/1000)%60, timestamp%1000);
    beats++;
    
    fVP_test = 1;;
}

int main() 
{
    testTimer.start();
    pc.baud(115200);

    pc.attach(&Rx_interrupt, Serial::RxIrq);
    apace.rise(&apace_isr);
    vpace.rise(&vpace_isr);
    master.start();
    while(1) 
    {
    }
}